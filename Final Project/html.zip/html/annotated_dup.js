var annotated_dup =
[
    [ "APP_LETIMER_PWM_TypeDef", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html", null ],
    [ "I2C_OPEN_STRUCT", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html", null ],
    [ "I2C_STATE_MACHINE", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e.html", null ],
    [ "LEUART_OPEN_STRUCT", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html", null ],
    [ "LEUART_STATE_MACHINE", "struct_l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html", null ]
];