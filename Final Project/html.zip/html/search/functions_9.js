var searchData=
[
  ['scheduled_5fletimer0_5fcomp0_5fcb_0',['scheduled_letimer0_comp0_cb',['../app_8c.html#a52609454c2bcb62915a021fd3bf37695',1,'app.c']]],
  ['scheduled_5fletimer0_5fuf_5fcb_1',['scheduled_letimer0_uf_cb',['../app_8c.html#a1a9d1e1d44bd0e250b4487029f89b091',1,'app.c']]],
  ['scheduler_5fopen_2',['scheduler_open',['../scheduler_8c.html#afbc09e3ce15ae2e0f91802ec1a8d2549',1,'scheduler.c']]],
  ['si1133_5fconfigure_3',['si1133_configure',['../_s_i1133_8c.html#a207635bd7d1b28d033893b90993eda07',1,'SI1133.c']]],
  ['si1133_5fi2c_5fopen_4',['Si1133_i2c_open',['../_s_i1133_8c.html#aa884f1eadce277729030da460c077813',1,'SI1133.c']]],
  ['si1133_5finitiate_5',['Si1133_initiate',['../_s_i1133_8c.html#af051fb53dd6a2d59afa64d1e0ffc60f4',1,'SI1133.c']]],
  ['si1133_5fpass_6',['Si1133_pass',['../_s_i1133_8c.html#aa4cae32165865f58e64fc67d75021b26',1,'SI1133.c']]],
  ['si1133_5fread_7',['Si1133_read',['../_s_i1133_8c.html#a35097b1f432121918bd47ec727ed6040',1,'SI1133.c']]],
  ['si1133_5fsense_8',['Si1133_sense',['../_s_i1133_8c.html#a44a0b802956b112a142279575528b1b4',1,'SI1133.c']]],
  ['si1133_5fwrite_9',['Si1133_write',['../_s_i1133_8c.html#a95c97079a1761ffb1f1312fc054e7a45',1,'SI1133.c']]],
  ['slave_5fack_10',['Slave_ACK',['../i2c_8c.html#aada41393df95e50131febbfaa471fc9b',1,'i2c.c']]],
  ['slave_5fnack_11',['Slave_NACK',['../i2c_8c.html#a6b849bfc2e5e2a8ba81fecfc9add7353',1,'i2c.c']]],
  ['sleep_5fblock_5fmode_12',['sleep_block_mode',['../sleep__routines_8c.html#ad3bf3466d014f1556634f36fa438169d',1,'sleep_routines.c']]],
  ['sleep_5fopen_13',['sleep_open',['../sleep__routines_8c.html#af7584e5af42c7017fb1236d686033a38',1,'sleep_routines.c']]],
  ['sleep_5funblock_5fmode_14',['sleep_unblock_mode',['../sleep__routines_8c.html#aac09e562117ae75c110cf084ddf66755',1,'sleep_routines.c']]]
];
