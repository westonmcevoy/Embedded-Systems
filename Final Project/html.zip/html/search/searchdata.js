var indexSectionsWithContent =
{
  0: "abceghilmrs",
  1: "ail",
  2: "abcghilms",
  3: "abcegilmrs",
  4: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Modules"
};

