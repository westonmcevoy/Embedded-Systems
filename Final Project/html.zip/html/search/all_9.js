var searchData=
[
  ['received_5fdata_0',['received_data',['../leuart_8c.html#a089cdfbc4f7506680a4ce0197f10e27a',1,'leuart.c']]],
  ['remove_5fscheduled_5fevent_1',['remove_scheduled_event',['../scheduler_8c.html#a89d9fd534ca49cadaeebe2048f2f6294',1,'scheduler.c']]],
  ['rgb_5finit_2',['rgb_init',['../_l_e_ds__thunderboard_8c.html#a5aa509ed3a4cfe6f812692e248618a51',1,'LEDs_thunderboard.c']]],
  ['rx_5fdatav_3',['RX_DataV',['../i2c_8c.html#a00a45cad78ae03a6c0f77045054dbbb2',1,'i2c.c']]]
];
