var _s_i1133_8c =
[
    [ "si1133_configure", "_s_i1133_8c.html#a207635bd7d1b28d033893b90993eda07", null ],
    [ "Si1133_i2c_open", "_s_i1133_8c.html#aa884f1eadce277729030da460c077813", null ],
    [ "Si1133_initiate", "_s_i1133_8c.html#af051fb53dd6a2d59afa64d1e0ffc60f4", null ],
    [ "Si1133_pass", "_s_i1133_8c.html#aa4cae32165865f58e64fc67d75021b26", null ],
    [ "Si1133_read", "_s_i1133_8c.html#a35097b1f432121918bd47ec727ed6040", null ],
    [ "Si1133_sense", "_s_i1133_8c.html#a44a0b802956b112a142279575528b1b4", null ],
    [ "Si1133_write", "_s_i1133_8c.html#a95c97079a1761ffb1f1312fc054e7a45", null ]
];