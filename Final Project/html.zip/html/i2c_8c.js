var i2c_8c =
[
    [ "I2C0_IRQHandler", "i2c_8c.html#a8e817e99d2a59e5f48e4ff0c79e7eef5", null ],
    [ "I2C1_IRQHandler", "i2c_8c.html#ac45e5675f6f4e6e1dee2273baf245219", null ],
    [ "i2c_bus_reset", "i2c_8c.html#ad392da40fbc730b1cb2562da0b0a4dcb", null ],
    [ "i2c_open", "i2c_8c.html#aedff09f3f341c200f1d0cb438ee94132", null ],
    [ "i2c_start", "i2c_8c.html#a1b1c1aae17b3c6f584406e59da29e66e", null ],
    [ "Is_Busy", "i2c_8c.html#adc6e7e69044d745b70f1f1dc97f53479", null ],
    [ "M_Stop", "i2c_8c.html#a61ab7356e6003a4742b14dfd6fab96a7", null ],
    [ "RX_DataV", "i2c_8c.html#a00a45cad78ae03a6c0f77045054dbbb2", null ],
    [ "Slave_ACK", "i2c_8c.html#aada41393df95e50131febbfaa471fc9b", null ],
    [ "Slave_NACK", "i2c_8c.html#a6b849bfc2e5e2a8ba81fecfc9add7353", null ]
];