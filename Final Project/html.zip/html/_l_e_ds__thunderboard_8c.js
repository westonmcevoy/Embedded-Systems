var _l_e_ds__thunderboard_8c =
[
    [ "leds_enabled", "_l_e_ds__thunderboard_8c.html#aeb9b41309fef8979aea6d87a983bf773", null ],
    [ "rgb_init", "_l_e_ds__thunderboard_8c.html#a5aa509ed3a4cfe6f812692e248618a51", null ]
];